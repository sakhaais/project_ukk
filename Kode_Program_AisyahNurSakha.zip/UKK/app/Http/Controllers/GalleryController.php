<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Komen;
use App\Models\Like;

use Illuminate\Http\Request;

class GalleryController extends Controller
{

    // REGISTER
    public function aksiregistrasi(Request $request)
    {
        $data = new User();
        $data->Username = $request->input('username');
        $data->Password = $request->input('password');
        $data->Email = $request->input('email');
        $data->NamaLengkap = $request->input('nama');
        $data->Alamat = $request->input('alamat');

        $data->save();

        return redirect ('/login');
    }
    
    // LOGIN
    public function aksilogin(Request $request)
    {
        $data = User::where('username', $request->input('username'))->where('password', $request->input('password'))->first();
        
        if($data != null){
            session()->put('user', $data);
            return redirect('/beranda');

        }else{
            return redirect()->back()->with('pesan','Username / Password Anda Salah!!');
        }
    }

    // ALBUM
    public function aksialbum (Request $request)
    {
        $data = new Album();
        $data->NamaAlbum = $request->input('namaalbum');
        $data->Deskripsi = $request->input('deskripsi');
        $data->TanggalDibuat = date('Y-m-d');
        $data->UserID = session('user')->UserID;

        $data->save();

        return redirect ('/album');
    }

    // FOTO
    public function uploadfoto (Request $request){
        if ($request->hasFile('file')) {
         
            $locate = $request->file('file')->store('public/image');

            $data = new Foto();
            $data->JudulFoto = $request->input('judul');
            $data->DeskripsiFoto = $request->input('deskripsi');
            $data->TanggalUnggah = date ('Y-m-d');
            $data->LokasiFile = $locate;
            $data->AlbumID = $request->get('album');
            $data->UserID = session('user')->UserID;
    
            $data->save();

            return redirect('/beranda');
        }
    }

    // ISI ALBUM
    public function isialbum ($AlbumID)
    {
        $album = Album::find($AlbumID);
        $foto = Foto::where('AlbumID', $AlbumID)->get();
        return view('gallery.isialbum', compact('album', 'foto'));
    }

    // INI LIKE 
    public function like($FotoID) {
        $cek = Like::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
    
        if(!$cek){
            $data = new Like();
            $data->FotoID = $FotoID;
            $data->UserID = session('user')->UserID;
            $data->TanggalLike = now();
            $data->save();
            return redirect()->back();
        } else {
            $cek->delete();
            return redirect()->back();
        }
    }

    public function komen(Request $request,$FotoID){

        $data = new Komen;
        $data->FotoID = $FotoID;
        $data->UserID = session('user')->UserID;
        $data->IsiKomentar = $request->input('komen');
        $data->TanggalKomentar= date('Y-m-d');
        $data->save();
        return redirect()->back();
    }

    // HAPUS FOTO
    public function hapusfoto($FotoID){

        $data = Foto::find($FotoID);
        $data->delete();
    
        return redirect('/isialbum');
    }

}
