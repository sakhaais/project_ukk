<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>G A L L E R Y ' S</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"/>
</head>

<style>
  
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        padding: 12px 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 9;
        background:#89ABE3;
    }

    .text {
        display: inline block;
        text-decoration: none;
        padding: 10px 10px;
        background-color: white;
        font-family: 'Gill Sans',;
        font-weight: 700;
        font-size: 15px;
        border-radius: 5px;
        box-shadow: 5px 8px 10px rgba(0, 0, 0, 0.3);
        margin-left: 70px;
        color: black;
    }


    .b a {
        position: relative;
        font-size: 1.1em;
        color: black;
        text-decoration: none;
        font-weight: 600;
        margin-left: 90px;
        font-family:'Poppins', sans-serif;
    }

    .b a::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: -6px;
        width: 100%;
        height: 3px;
        background: black;
        border-radius: 5px;
        transform: scaleX(0);
        transition: transform .3s;
    }

    .b a:hover::after {
        transform: scaleX(1);
    } 

    h2 {
        font-family: 'Gill Sans', 'Gill Sans MT';
        font-weight: bold;
        color: black;
    }

    .nama {
        font-family: 'candara';
        font-weight: 700;
        text-shadow: 0px 5px 5px rgba(0, 0, 0, 0.5);
        margin-bottom: 5px;
        margin-left: 2%;
        font-size: 24px;
    }

    .logo {
        font-family: 'candara';
        font-weight: 700;
        color:#FF3131;
        font-size: 25px;
        margin-right: 32%;
        margin-bottom: 9px;
    }

    svg {
        color: black;
        margin-bottom: 7px;
    }

    .container {
        position: relative;
        display: flex;
        justify-content: center;
        align-items:center;
        flex-wrap: wrap;
        gap: 20px 20px;
        padding: 0px 0px;
    }

    .container .card {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        width: 350px;
        max-width: 100%;
        height: 300px;
        background:#89ABE3;
        box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.15);
        transition: 0.5s;
        border-radius: 10px;
        margin-top: 80px;
    }

    .container .card .img-box {
        position : absolute;
        top: 20px;
        width: 300px;
        height: 220px;
        overflow: hidden;
        border-radius: 10px;
        transition: 0.5s;
        margin-left: 25px;
    }

    .container .card:hover {
        height: 300px;
    }

    .container .card:hover .img-box {
        top: -100px ;
        scale: 0.75;
        box-sizing: 0 15px 45px rgba(0, 0, 0, 0.2);
    }

    .container .card .img-box img {
        position: absolute;
        top: 0px;
        left: 0;
        width: 100%;
        height: 100%;  
        object-fit: cover;
    }

    .container .card .content {
        position: absolute;
        top: 252px;
        width: 100%;
        height: 45px;
        padding: 0 30px;
        text-align: center;
        overflow: hidden;
        transition: 0.5s;
    }

    .container .card:hover .content {
        top: 110px;
        height: 250px;
    }

    .container .card .box h2 {
        font-weight: 700;
        font-family: 'candara';
    } 

    .container .card .content p {
        margin-top: 10px;
    } 

    .container .card .content .btn {
        position: relative;
        display: inline-block;
        padding: 12px 15px;
        background-color: black;
        text-decoration: none;
        color: white;
        font-weight: 500;
        border-radius: 5px;
    } 

</style>

<body>

  <header>

    <a href= "javascript:history.go(-1)"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
    </svg></a>

    <h2 class="nama">G A L L E R Y ' S</h4>
      
    <p class="logo">{{ session('user')->Username }}</p>

      <div class="button">
        <a href="/tambahalbum" class="text">tambah album</a>
        <a href="/tambahfoto" class="text">tambah foto</a>
      </div>

      <nav class="b">
        <a href="/">Logout</a>  
      </nav>

  </header>
             
      <div class="container">

        @foreach($album as $field)   

        <div class="card">

          <div class="img-box">
            <img src="img/album.svg">
          </div>

        <div class="content">

          <h2>{{ $field->NamaAlbum}}</h2>
          <p>{{ $field->Deskripsi}}</p>
         
          <a href="/album{{$field->AlbumID}}" class="btn">Lihat Foto</a>
          
        </div>

        </div>

        @endforeach

      </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

  </body>
</html>