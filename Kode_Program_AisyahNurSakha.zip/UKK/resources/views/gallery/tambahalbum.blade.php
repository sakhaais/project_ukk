<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>G A L L E R Y ' S</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box; 
            font-family:'Poppins', sans-serif; 
        }

        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        padding: 15px 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 9;
        background:#89ABE3;
    }

    .b a {
        position: relative;
        font-size: 1.1em;
        color: black;
        text-decoration: none;
        font-weight: 600;
        margin-left: 50px;
    }

    .b a::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: -6px;
        width: 100%;
        height: 3px;
        background: black;
        border-radius: 5px;
        transform: scaleX(0);
        transition: transform .3s;
    }

    .b a:hover::after {
        transform: scaleX(1);
    } 

    h2 {
        font-family: 'candara';
        font-weight: 700;
        text-shadow: 0px 5px 5px rgba(0, 0, 0, 0.5);
        margin-bottom: 5px;
        margin-left: 30px;
    }

    p {
        font-family: 'candara';
        font-weight: 700;
        color:#FF3131;
        font-size: 25px;
        margin-right: 66%;
        margin-bottom: 9px;
    }

    svg {
        color: black;
        margin-right: 0%;
    }

        .container {
            position: relative;
            max-width: 700px;
            width: 100%;
            background:  #F7CACA;
            padding: 25px;
            border-radius: 10px;
            box-shadow:  15px 15px rgba(0, 0, 0, 0.5);
        }

        .container .form    {
            margin-top: 10px;
        }

        .form .input-box    {
            width: 100%;
            margin-top: 10px;
        }
    
        .form :where(.input-box input, .select-box,)    {
            position: relative;
            height: 50px;
            width: 100%;
            outline: none;
            font-size: 1rem;
            border: 1px solid;
            border-radius: 7px;
            padding: 0 15px;
            margin-top: 9px;
        }

        .select-box select {
            width: 100%;
            height: 100%;
            outline: none;
            border: none;
            font-size: 1rem;
        }

        .form button {
             height: 50px;
             width: 20%;
             color: white;
             font-size: 1rem;
             border: none;
             margin-top: 30px;
             cursor: pointer;
             border-radius: 10px;
             font-weight: 400;  
             background-color: black;
             transition:  all 0.3s ease;
         } 

    </style>

</head>

<body>

    <header>
         
    <a href= "javascript:history.go(-1)"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
    </svg></a>
         
        <h2>G A L L E R Y ' S </h2>

        <p>{{ session('user')->Username }}</p>

            <nav class="b">
                <a href="/">Logout</a> 
                </nav>

    </header>

    <section class="container">

        <form action="/album" method="POST" class="form">

            @csrf

                <div class="input-box">
                    <label for="">Nama Album</label >
                        <input type="text" name="namaalbum" Required>
                </div>
            
                <div class="input-box">
                     <label for="">Deskripsi Album</label >
                        <input type="text" name="deskripsi" Required>
                </div>

                <button>Buat</button>

        </form>

    </section>
    
</body>

</html>