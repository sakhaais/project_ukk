<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>G A L L E R Y ' S</title>

  <style>
  
    * {
        margin : 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Gill Sans', 'Gill Sans MT';
    }

    body {
        display: flex;
        justify-content: center;
        background-color: #93a9d1;
    }

    header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        padding: 10px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 9;
        background-color: #93a9d1;
    }

    svg {
        color: black;
    }

    .container {
        margin-top: 7%;
        width: 28%;
        display: flex;
        background: #f7caca;
        border-radius: 25px;
        border-bottom-left-radius: 0px;
        box-shadow: 20px 20px 20px  rgba(0, 0, 0, 0.5);
        padding: 20px;
    }

    form {
        width: 300px;
    }

    h1 {
        text-align: center;
        font-weight: bolder;
        text-transform: uppercase;
        margin-left: 5px;
    }

    hr {
        border-top: 3px solid;
        width: 300px;
        background-color: black;
    }  

    form label {
        font-size: 16px;
        font-weight: 600;
    }

    input {
        width: 100%;
        margin: 10px;
        border: none;
        outline: none;
        padding: 10px;
        border-radius: 20px;
        border: 2px solid black;
    }

    .btn {
        width: 100px;
        background: black;
        color: white;
        margin-left: 25px;
    }

    .btn:hover {
        cursor: pointer;
    } 

    p {
        margin-left: 30px;
    }

    svg {
        margin-right: 85%;
        margin-bottom: 0px;
    }

    .pesan {
        color: red;
        margin-left: 35px; 
    }

  </style>
  
</head>

<body>

    <header>
    <a href="javascript:history.go(-1)"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
    </svg></a>
    </header>

  <div class="container">

      <form action="/login" method="POST">

        @csrf

          <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
          <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
          <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
          </svg>

          <center class="pesan">{{session()->get('pesan')}}</center>

        <br>

        <label for="">Username</label>
        <input type="text"
        placeholder="Masukkan Username" required name="username">

        <br>

        <label for="">Password</label>
        <input type="password"
        placeholder="Masukkan Password" required name="password">

        <br>

        <center>
        <input class="btn" type="submit" value="Login">
        <p>
          Belum Punya Akun? <a href="/register">Daftar</a>
        </p>
        </center> 

      </form>

    </div>

</body>

</html>