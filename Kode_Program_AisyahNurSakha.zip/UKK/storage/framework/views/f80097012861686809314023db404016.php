<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>G A L L E R Y ' S</title>

  <style>

    html {
      margin: 0;
      padding: 0;
    }

    body {
      margin: 0;
      padding: 0;
      width: 100%;
      background: #89ABE3;
      background-repeat: no-repeat;  
      display: block;
    }

    .header{
      text-align: center;
      position: absolute;
      top: 40%;
      left: 50%;
      transform: translate(-0%, -70%);
    }

    .header h1{
      color: black;
      text-align: left;
      font-family: 'candara';
      font-size: 80px; 
      text-shadow: 10px 10px 10px rgba(0, 0, 0, 0.5);
    }

    .content-header {
      position: absolute;
      transform: translate(-10%, -40%);
      text-align: center;
      top: 55%;
      left: 55%;
    }

    .content-header p {
      color: black;
      font-family:'Gill Sans', 'Gill Sans MT';
      font-size: 23px;
      text-align: left;
    }

    .btn {
      display: inline block;
      text-decoration: none;
      padding: 10px 30px;
      color: black;
      background-color: #FCBCFB;
      font-family: 'Gill Sans', 'Gill Sans MT';
      border-radius: 25px;
      margin-right: 30px;
      font-weight: bold;
      box-shadow: 5px 10px 10px rgba(0, 0, 0, 0.5);
    }

    .btn:hover {
      background-color: #F7CACA;
      transition:  all 0.3s ease;
    }

    .img {
      position: absolute;
      top: 50%;
      left: 12%;
      transform: translate(-50%, -50%);
      width: 63%;
      text-align: -webkit-right;
    }

    .img img {
      width: 70%;
    }

  </style>

</head>

<body>

  <div class="header">

    <h1>G A L L E R Y ' S</h1>
    
  </div>

  <div class="content-header">

    <p>Menampilkan Karya Seni Yang Tertangkap Oleh Kamera</p>
    <br>
    <br>
    <a href="/login" class="btn">GET STARTED</a>

  </div>

  <div class="img">
    <img src="img/home.svg" alt="">
  </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\UKK\resources\views/gallery/home.blade.php ENDPATH**/ ?>