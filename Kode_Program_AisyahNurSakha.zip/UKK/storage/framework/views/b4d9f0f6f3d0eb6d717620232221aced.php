<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>G A L L E R Y ' S</title>
  
  <style>
  
    * {
        margin : 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Gill Sans', 'Gill Sans MT';
    }

    body {
        display: flex;
        justify-content: center;
        background-color: #93a9d1;
    }
    
    header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        padding: 10px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 9;
        background-color: #93a9d1;
    }
  
    svg {
        color: black;
    }

    .container {
        width: 30%;
        display: flex;
        background: #f7caca;
        border-radius: 25px;
        box-shadow: 20px 20px 15px rgba(0, 0, 0, 0.5);
        margin-top: 5%;
        margin: 5%;
    }

    form {
        width: 295px;
        margin: 25px;
    }

    h1 {
        text-align: center;
        font-weight: bolder;
        text-transform: uppercase;
        margin-left: 5px;
    }

    hr {
        border-top: 3px solid;
        width: 320px;
        background-color: black;
    }  

    form label {
        font-size: 16px;
        font-weight: 600;
    }

    input {
        width: 100%;
        margin: 10px;
        border: none;
        outline: none;
        padding: 10px;
        border-radius: 20px;
        border: 2px solid black;
    }

    .btn {
        width: 100px;
        background: black;
        margin-left: 30px;
        color:white;
    }

    .btn:hover {
        cursor: pointer;
    }

  </style>
  
</head>

<body>

    <header>

    <a href="javascript:history.go(-1)"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
    </svg></a>

    </header>

  <div class="container">

      <form action="/register" method="POST">

        <?php echo csrf_field(); ?>

        <h1>Register</h1>

        <br>

        <hr>

        <br>

        <label for="">Nama</label>
        <input type="text"
        placeholder="Masukkan Nama" required name="nama">

        <br>

        <label for="">Email</label>
        <input type="email"
        placeholder="Masukkan Email" required name="email">

        <br>

        <label for="">Username</label>
        <input type="text"
        placeholder="Masukkan Username" required name="username">

        <br>

        <label for="">Password</label>
        <input type="password"
        placeholder="Masukkan Password" required name="password">

        <br>

        <label for="">Alamat</label>
        <input type="text"
        placeholder="Masukkan Alamat" required name="alamat">

        <br>

        <center>
        <input class="btn" type="submit" value="Daftar">
        </center> 

      </form>

    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\UKK\resources\views/gallery/register.blade.php ENDPATH**/ ?>