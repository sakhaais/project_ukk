<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <title>G A L L E R Y ' S</title>

  <style>
  
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box; 
        font-family:'Poppins', sans-serif; 
    }

    body {
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background-color: #f0f0f0;
    }
 
   
    header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        padding: 15px 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 9;
        background:#89ABE3;
    }

    .b a {
        position: relative;
        font-size: 1.1em;
        color: black;
        text-decoration: none;
        font-weight: 600;
        margin-left: 50px;
    }

    .b a::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: -6px;
        width: 100%;
        height: 3px;
        background: black;
        border-radius: 5px;
        transform: scaleX(0);
        transition: transform .3s;
    }

    .b a:hover::after {
        transform: scaleX(1);
    } 

    h2 {
        font-family: 'candara';
        font-weight: 700;
        text-shadow: 0px 5px 5px rgba(0, 0, 0, 0.5);
        margin-bottom: 5px;
        margin-left: 30px;
    }

    .logo {
        font-family: 'candara';
        font-weight: 700;
        color:#FF3131;
        font-size: 25px;
        margin-right: 55%;
        margin-bottom: 9px;
    }

    svg {
        color: black;
        margin-right: 0%;
    }

    .container {
        height: 150%;     
        margin-top: 25%;
    }

    .card {
        display: flex;
        overflow: hidden;
        width: 600px;
        box-shadow: 0 10px 10px rgba(0, 0, 0, 0.5);
        border-radius: 8px;
        margin-top: 80px;
    }

    .half-image {
        width: 50%; 
        height: auto;
     }

    .card-content {
        flex: 1;
        padding: 20px;
        background-color: #fff;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    h3 {
        margin-top: 0;
        font-size: 1.5em;
    }

    p {
        margin-bottom: 0;
        color: #555;
    }

    .like-comment-container {
        display: flex;
        align-items: center;
    }

    .like-icon {
        color: red;
        margin-right: 10px;
        cursor: pointer;
    }

    .comment-input {
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        flex-grow: 1;
    }

    .user {
        color:black;
        font-family: 'Gill Sans', 'Gill Sans MT';
        font-weight: 700;
        margin-left: 200px;
    }

</style>

</head>

<body>

  <header>

    <a href= "javascript:history.go(-2)" ><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
    </svg></a>

    <h2>G A L L E R Y ' S </h2>

    <p class="logo"><?php echo e(session('user')->Username); ?></p>

      <nav class="b">
        <a href="/album">My Album</a>
        <a href="/">Logout</a> 
      </nav>

  </header>

  <div class="container">

    <div class="card">
      <img src="<?php echo e(Storage::url($field->LokasiFile)); ?>" alt="Foto" class="half-image">

    <div class="card-content"> 
     
      <center>
        <h3><?php echo e($field->JudulFoto); ?></h3>
        <br>
        <p><?php echo e($field->DeskripsiFoto); ?></p>
      </center> 
          
    <div class="icons">
    <!-- ini isi komen  -->
      <div class="text-start ps-5" style="margin-top: 20vh;">
        <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="mb-2">
            <div class="fw-bold text-muted" style="color:#FF3131; font-family: 'Gill Sans', 'Gill Sans MT'; font-weight: 700;"><?php echo e(\App\Models\User::where('UserID',$komen->UserID)->first()->Username); ?> 
              <span class="fw-bolder" style="font-size: 13px; color: black; font-family: Courier New;"><?php echo e($komen->TanggalKomentar); ?></span>
            </div>
              <span><?php echo e($komen->IsiKomentar); ?></span>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div> 

        <br>

        <div>
          <!-- ini komen -->
          <form action="/komen/<?php echo e($field->FotoID); ?>" method="post">
            <?php echo csrf_field(); ?>
              <input type="text" class="comment-input" placeholder="Tambah Komentar..." name="komen">
          </form>

            <br>

            <!-- ini like -->
          <form action="/like/<?php echo e($field->FotoID); ?>" method="post">
            <?php echo csrf_field(); ?>

              <?php if($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $field->FotoID)->first()): ?>

                <button style="background: none; border: none;" type="submit">

                  <i class="fa-solid fa-heart" style="color: red;"></i>

              <?php echo e($like->where('FotoID', $field->FotoID)->count()); ?></button>

              <?php else: ?>
                <button style="background: none; border: none;" type="submit"><i class="fa-solid fa-heart" style="color: black;"> </i>

              <?php echo e($like->where('FotoID', $field->FotoID)->count()); ?></button>

              <?php endif; ?>

              <p class="user">
    
                <?php if($nama = $user->where('UserID', $field->UserID)->first()): ?><?php echo e($nama->Username); ?>


                <?php endif; ?> 
              </p> 

          </form>

    </div>

  </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\UKK\resources\views/gallery/deskripsi.blade.php ENDPATH**/ ?>