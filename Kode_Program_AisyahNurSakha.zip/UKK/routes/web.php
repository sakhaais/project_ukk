<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GalleryController;
use App\Models\User;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Komen;
use App\Models\Like;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('gallery.home');
});

Route::get('/login', function () {
    return view('gallery.login');
});

Route::post('/login',[GalleryController::class,'aksilogin']);

Route::get('/register', function () {
    return view('gallery.register');
});

Route::post('/register',[GalleryController::class,'aksiregistrasi']);

Route::get('/beranda', function () {
    $foto = Foto::all();
    return view('gallery.beranda', compact('foto'));
});

Route::post('/beranda',[GalleryController::class,'uploadfoto']);

Route::get('/album', function () {
    $album = Album::where('UserID', session('user')->UserID)->get();
    return view('gallery.album', compact('album'));
});

Route::post('/album',[GalleryController::class,'aksialbum']);

Route::get('/tambahalbum', function () {
    return view('gallery.tambahalbum');
});

Route::get('/tambahfoto', function () {
    $album = Album::where('UserID', session('user')->UserID)->get();
    return view('gallery.tambahfoto', compact('album'));
});

Route::get('/isialbum', function () {
    $foto = Foto::where('UserID', session('user')->UserID)->get();
    return view('gallery.isialbum', compact('foto'));
});

Route::get('/album{FotoID}',[GalleryController::class,'isialbum']);

Route::get('/deskripsi/{FotoID}', function ($FotoID) {
    $field = Foto::where('FotoID', $FotoID)->first();
    $komentar = Komen::where('FotoID', $FotoID)->get();
    $like = Like::where('FotoID', $FotoID)->get();
    $user = User::All();
    return view('gallery.deskripsi', compact('field', 'komentar', 'like', 'user')); 
});


Route::post('/like/{FotoID}',[GalleryController::class,'like']);

Route::post('/komen/{FotoID}',[GalleryController::class,'komen']);

Route::get('/hapusfoto/{FotoID}',[GalleryController::class,'hapusfoto']);