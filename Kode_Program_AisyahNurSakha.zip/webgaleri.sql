-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Feb 2024 pada 03.48
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webgaleri`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `album`
--

CREATE TABLE `album` (
  `AlbumID` int(11) NOT NULL,
  `NamaAlbum` varchar(255) NOT NULL,
  `Deskripsi` text NOT NULL,
  `TanggalDIbuat` date NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `album`
--

INSERT INTO `album` (`AlbumID`, `NamaAlbum`, `Deskripsi`, `TanggalDIbuat`, `UserID`) VALUES
(2, 'Anime', 'Sekumpulan orang ganteng', '2024-02-20', 1),
(3, 'Makanan', 'Sekumpulan foto makanan yang menggugah selera', '2024-02-20', 1),
(5, 'Film', 'Sekumpulan film yang bagus', '2024-02-20', 2),
(8, 'Hewan', 'Sekumpulan foto hewan', '2024-02-21', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `foto`
--

CREATE TABLE `foto` (
  `FotoID` int(11) NOT NULL,
  `JudulFoto` varchar(255) NOT NULL,
  `DeskripsiFoto` text NOT NULL,
  `TanggalUnggah` date NOT NULL,
  `LokasiFile` varchar(255) NOT NULL,
  `AlbumID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `foto`
--

INSERT INTO `foto` (`FotoID`, `JudulFoto`, `DeskripsiFoto`, `TanggalUnggah`, `LokasiFile`, `AlbumID`, `UserID`) VALUES
(4, 'Anime', 'the boy and the heron', '2024-02-20', 'public/image/2CmZa0nGHX33L8ODI8pOMUssaFMhT0mzYHUFx7z8.jpg', 2, 1),
(5, 'gembul', 'lucuuu', '2024-02-20', 'public/image/EsTBrao1yNpz5yW3RCF9Iz2i9E8cocKHoRkpsKzL.jpg', 2, 1),
(7, 'Mie Nyemek', 'bikin ngiler', '2024-02-20', 'public/image/5Aop5xKZuAUXvC0i3UgtlaiJADIcoEi5jvAlAxgT.jpg', 3, 1),
(8, 'Dessert', 'Cromboloni', '2024-02-20', 'public/image/5q2WNKD5zs1PhQdLcN4DKDlSY8UhTEgMINUaI0Ko.jpg', 3, 1),
(9, 'Tteobokki', 'warnanyaa pekat bangett', '2024-02-20', 'public/image/zifQfrRuQHLsQgR1iuRw43qpUsYaXQ5UbcWxhfoH.jpg', 3, 1),
(10, 'Ayam', 'sedep', '2024-02-20', 'public/image/eN5KjAsDYYmtTBSm9WEa4C6oOEZaUe5uvrhaUKl9.jpg', 3, 1),
(11, 'kakek-kakek', 'putih', '2024-02-20', 'public/image/VbwCfSGSt0bW2mY5ELtYkaBF08VwRUiqtmyAM3JN.jpg', 2, 1),
(14, 'Drama Korea', 'Partner For Justice', '2024-02-20', 'public/image/2ROO0W4VMLcbDh6J2eRBKLidublQPc96KLPmXjcV.jpg', 5, 2),
(15, 'Anime', 'Spirited Away', '2024-02-20', 'public/image/fuxYGQdflyJSnGC81dsW0dF8cBHp1voPfL7EdsYq.jpg', 5, 2),
(16, 'drakor', 'bagus', '2024-02-20', 'public/image/vQypQcTqjjInCRNf6gw1eB1CUQkZSafzSnAFFdWy.jpg', 5, 2),
(17, 'anime the best', 'seruuuuu', '2024-02-20', 'public/image/LtdLvSFKJD5ga6y40EcmshuOOxk5NkyLyZxqjDGk.jpg', 5, 2),
(18, 'totoro', 'lucu filmnya', '2024-02-20', 'public/image/L3ys0FztudE7No00vxYeSCzVk8WVMrjsbRrG86mL.jpg', 5, 2),
(19, 'ponyo', 'saske & ponyo', '2024-02-20', 'public/image/ksHii3XfXiqXKweq6pOQEiTGfFZEu1aRllsjGlkg.jpg', 2, 1),
(21, 'Studio Ghibli', 'Arierty', '2024-02-20', 'public/image/qasFYrbSCyfZIYShdv01LhdaNYdBNtsaVvQ8UwxV.jpg', 2, 1),
(25, 'ghibli pt 2', 'Princess Mononoke', '2024-02-21', 'public/image/YtithZfjlQgHnwIagb4WnZxWuteamHpfXkoWAPAq.jpg', 2, 1),
(28, 'HARRY POTTER', 'film fantasi ter the besttttt', '2024-02-21', 'public/image/CoTnbWZpfaUoN5raEbSDvzEoZrNB4un08gyVUtbc.jpg', 5, 2),
(29, 'rubah', 'hewan', '2024-02-21', 'public/image/af3KtOb35Lrc0XoMMsVK3XqW0ILPW0O9yt7olnkm.jpg', 8, 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `KomentarID` int(11) NOT NULL,
  `FotoID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `IsiKomentar` text NOT NULL,
  `TanggalKomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `komentarfoto`
--

INSERT INTO `komentarfoto` (`KomentarID`, `FotoID`, `UserID`, `IsiKomentar`, `TanggalKomentar`) VALUES
(7, 8, 1, 'kronologi', '2024-02-20'),
(8, 16, 1, 'bagus emang drakor ini', '2024-02-20'),
(9, 20, 1, 'lucu sekali', '2024-02-20'),
(13, 15, 1, 'bagus ini anime', '2024-02-21'),
(14, 25, 2, 'wow', '2024-02-21'),
(15, 4, 2, 'gerbang surga', '2024-02-21'),
(16, 25, 2, 'anime', '2024-02-21'),
(17, 7, 2, 'wihhh', '2024-02-21'),
(18, 7, 2, 'enak ni', '2024-02-21'),
(19, 29, 4, 'rubah', '2024-02-21'),
(20, 28, 1, 'asli film ini bagus banget', '2024-02-21');

-- --------------------------------------------------------

--
-- Struktur dari tabel `likefoto`
--

CREATE TABLE `likefoto` (
  `LikeID` int(11) NOT NULL,
  `FotoID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `TanggalLike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `likefoto`
--

INSERT INTO `likefoto` (`LikeID`, `FotoID`, `UserID`, `TanggalLike`) VALUES
(1, 8, 1, '2024-02-20'),
(2, 16, 1, '2024-02-20'),
(3, 14, 1, '2024-02-20'),
(4, 20, 1, '2024-02-20'),
(5, 5, 1, '2024-02-20'),
(6, 8, 2, '2024-02-20'),
(7, 15, 1, '2024-02-21'),
(10, 25, 1, '2024-02-21'),
(11, 25, 2, '2024-02-21'),
(12, 7, 2, '2024-02-21'),
(13, 29, 4, '2024-02-21'),
(14, 28, 1, '2024-02-21');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `NamaLengkap` varchar(255) NOT NULL,
  `Alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`) VALUES
(1, 'sakha', '090307', 'aisyah050584@gmail.com', 'Aisyah Nur Sakha', 'Karang Asam'),
(2, 'juhwa', '1029', 'limjuhwan@gantengbgttt', 'Lim Ju-Hwan', 'Korea Selatan'),
(4, 'bils', '098', 'billa@gmail.com', 'Billa', 'tegal rejo');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`AlbumID`);

--
-- Indeks untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`FotoID`);

--
-- Indeks untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`KomentarID`);

--
-- Indeks untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`LikeID`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `album`
--
ALTER TABLE `album`
  MODIFY `AlbumID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `foto`
--
ALTER TABLE `foto`
  MODIFY `FotoID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `KomentarID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `LikeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
